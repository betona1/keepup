---
name: KeepUp
colors:
  surface: '#f7f9ff'
  surface-dim: '#d7dadf'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f9'
  surface-container: '#ebeef3'
  surface-container-high: '#e5e8ee'
  surface-container-highest: '#e0e3e8'
  on-surface: '#181c20'
  on-surface-variant: '#444654'
  inverse-surface: '#2d3135'
  inverse-on-surface: '#eef1f6'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2a50d8'
  primary: '#274ed5'
  on-primary: '#ffffff'
  primary-container: '#4669f0'
  on-primary-container: '#fffbff'
  inverse-primary: '#b8c4ff'
  secondary: '#b32a19'
  on-secondary: '#ffffff'
  secondary-container: '#fc5e47'
  on-secondary-container: '#5f0400'
  tertiary: '#006b23'
  on-tertiary: '#ffffff'
  tertiary-container: '#098730'
  on-tertiary-container: '#f7fff1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001355'
  on-primary-fixed-variant: '#0036bc'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a7'
  on-secondary-fixed: '#400200'
  on-secondary-fixed-variant: '#900e02'
  tertiary-fixed: '#8dfa94'
  tertiary-fixed-dim: '#71dd7a'
  on-tertiary-fixed: '#002106'
  on-tertiary-fixed-variant: '#005319'
  background: '#f7f9ff'
  on-background: '#181c20'
  surface-variant: '#e0e3e8'
typography:
  headline-lg:
    fontFamily: Nanum Gothic
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Nanum Gothic
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Nanum Gothic
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 26px
  title-md:
    fontFamily: Nanum Gothic
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
  body-lg:
    fontFamily: Nanum Gothic
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Nanum Gothic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Nanum Gothic
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Nanum Gothic
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
  headline-lg-mobile:
    fontFamily: Nanum Gothic
    fontSize: 26px
    fontWeight: '800'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  margin-mobile: 16px
  margin-desktop: 32px
  gutter: 16px
  fab-offset: 20px
---

## Brand & Style

The brand identity of the design system centers on the concept of "Physical Certification." It bridges the gap between digital habit tracking and the tangible satisfaction of a physical planner. The core metaphor is the **Traditional Ink Stamp**, representing a formal signature, a personal commitment, and a definitive mark of completion.

The visual style is **Corporate / Modern** with a **Tactile** twist. It utilizes a professional, structured framework—defined by clear geometric boundaries and robust typography—softened by generous whitespace and large corner radii. The interface should feel "sturdy" yet "airy," providing a calm environment for discipline while using high-contrast "stamp" moments to trigger a dopaminergic response upon habit completion.

**Key visual principles:**
- **The Signature Mark:** Completion is never a simple checkbox; it is an organic, slightly tilted red stamp that "breaks" the digital grid.
- **Paper-like Canvas:** The background isn't sterile white but a subtle, cool grey that mimics high-quality stationary.
- **Refined Strength:** Heavy font weights and thick borders on interactive elements convey reliability and institutional trust.

## Colors

The palette is anchored by **Trust Indigo**, providing a professional foundation for navigation and secondary actions. The **Signature Stamp Red** is reserved strictly for moments of achievement, completion, and the brand's "certification" mark.

- **Primary (Indigo):** Used for the "path"—navigation, focus states, and primary buttons.
- **Secondary (Stamp Red):** Used for the "destination"—completion indicators, progress bars, and stamps.
- **Background:** A cool paper-grey (`#F6F7FC`) to create depth against white surface cards.
- **Functional States:** Success uses a deep Forest Green (`#2F9E44`), while Error/Urgency uses a vibrant Coral Red (`#FA5252`).
- **Tonal Accents:** Use a 10% opacity version of Stamp Red (`#FDEEEB`) for badges and "soft" completion states to ensure the vibrant red ink remains legible and sophisticated.

## Typography

The design system exclusively uses **Nanum Gothic** for its modern, clean, and hyper-legible characteristics. The type scale is heavily weighted toward ExtraBold (`800`) for headers to establish a solid, authoritative structure.

- **Editorial Headlines:** High-level headers use tight letter-spacing and heavy weights to create an impactful, editorial feel.
- **Body Copy:** Maintains a relaxed line height (`1.5x` or `1.6x`) to ensure that long habit descriptions or user notes remain comfortable to read on mobile devices.
- **Micro-Copy:** Labels and badges are always uppercase or bolded to ensure they function as clear visual anchors despite their small size.

## Layout & Spacing

This design system uses a **Fluid Grid** model with high-density padding on internal components and spacious margins between sections. 

- **The 8pt Rhythm:** All spacing and component heights must be multiples of 4px, with 8px and 16px as the primary increments for layout.
- **Mobile Foundation:** A strict 16px side margin is maintained for all mobile screens. On larger devices (tablets/desktops), content containers are centered with a `max-width` of 768px for reading views or 1024px for grid views.
- **Safe Zones:** Lists and scrollable areas must include a bottom padding of at least 96px to prevent the Floating Action Button (FAB) from obscuring the final item in a list.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layers** and **Low-Contrast Outlines** rather than aggressive shadows. This keeps the interface looking professional and "flat" like a paper journal.

- **Surface Layering:** The primary canvas is `#F6F7FC`. Interactive cards are pure `#FFFFFF`.
- **Structural Outlines:** Instead of heavy shadows, cards use a `1px` hairline border in `#E7EAF3`.
- **Soft Depth:** Only the primary Floating Action Button (FAB) and high-priority modals may use a very diffused, 10% opacity Indigo-tinted shadow to suggest a slight lift from the surface.
- **Interactive State:** On hover or press, cards do not lift; instead, their border color transitions from the subtle grey to the **Brand Indigo**.

## Shapes

The shape language is defined by **large, friendly radii** that contrast with the sturdy typography.

- **Cards & Sheets:** Use the largest radius (20px) to create a distinct, containerized look that feels like a physical card.
- **Inputs & Buttons:** Use a medium radius (14px) to balance touch-target comfort with structural alignment.
- **Badges & Chips:** Use a full pill shape (`rounded-full`) to differentiate them from functional inputs.
- **The Stamp:** An exception to the geometric rule, the stamp is a circular component with an organic, `-8 degree` tilt, breaking the rigid alignment of the rest of the UI.

## Components

### Buttons
- **Primary FAB:** An extended pill-shaped button. Indigo background, white text/icon, 18px radius.
- **Action Buttons:** 14px radius, bold text. Filled for primary actions (Indigo), soft-tinted for secondary (10% Indigo background).

### The Signature Stamp (StampMark)
The defining component of the system.
- **Visuals:** A thick circular border (8% of size) in Stamp Red.
- **Uncompleted:** A hollow circle with a "-8 degree" tilt and "UP!" text in the center.
- **Completed:** A filled circle (10% red tint) with a thick, sharp red checkmark, overlaid on the habit card.

### Cards
- **Habit Card:** Pure white, 20px radius, 1px subtle border. Contains a circular action icon on the left (50px), progress bar at the bottom, and title/status chips in the center.
- **Quote Banner:** Rich gradient (Indigo `#5C7CFA` to Deep Indigo `#3B5BDB`), 20px radius. White text, with a small Stamp Red accent circle next to the attribution.

### Inputs & Progress
- **Fields:** Filled style with `#F6F7FC` background and 14px radius. No border except on focus (Brand Indigo).
- **Progress Bars:** Thin 5px tracks with rounded ends. The unfilled track is light grey; the progress line is solid Stamp Red.

### Navigation
- **Bottom Bar:** Solid white, flat elevation. Active items use a 12% Indigo pill background behind the icon to indicate selection.
- **Marquee:** A secondary navigation element under the header that scrolls active habit names in 11px bold Indigo text.