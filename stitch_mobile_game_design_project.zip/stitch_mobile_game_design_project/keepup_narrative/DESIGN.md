---
name: KeepUp Narrative
colors:
  surface: '#f8f9fe'
  surface-dim: '#d8dadf'
  surface-bright: '#f8f9fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3f8'
  surface-container: '#eceef3'
  surface-container-high: '#e7e8ed'
  surface-container-highest: '#e1e2e7'
  on-surface: '#191c1f'
  on-surface-variant: '#444654'
  inverse-surface: '#2e3134'
  inverse-on-surface: '#eff0f5'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2a50d8'
  primary: '#274ed5'
  on-primary: '#ffffff'
  primary-container: '#4669f0'
  on-primary-container: '#fffbff'
  inverse-primary: '#b8c4ff'
  secondary: '#b32a19'
  on-secondary: '#ffffff'
  secondary-container: '#fc5e47'
  on-secondary-container: '#5f0400'
  tertiary: '#645a58'
  on-tertiary: '#ffffff'
  tertiary-container: '#7d7270'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001355'
  on-primary-fixed-variant: '#0036bc'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a7'
  on-secondary-fixed: '#400200'
  on-secondary-fixed-variant: '#900e02'
  tertiary-fixed: '#eedfdc'
  tertiary-fixed-dim: '#d1c4c1'
  on-tertiary-fixed: '#211a18'
  on-tertiary-fixed-variant: '#4e4543'
  background: '#f8f9fe'
  on-background: '#191c1f'
  surface-variant: '#e1e2e7'
typography:
  headline-lg:
    fontFamily: Nanum Gothic
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
  headline-lg-mobile:
    fontFamily: Nanum Gothic
    fontSize: 22px
    fontWeight: '800'
    lineHeight: 28px
  title-lg:
    fontFamily: Nanum Gothic
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 25px
  title-md:
    fontFamily: Nanum Gothic
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
  label-lg:
    fontFamily: Nanum Gothic
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
  label-sm:
    fontFamily: Nanum Gothic
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
  body-md:
    fontFamily: Nanum Gothic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Nanum Gothic
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 16px
  section-gap: 24px
  element-gap: 12px
  inline-gap: 8px
  grid-gutter: 12px
---

## Brand & Style

This design system is built on the philosophy of the **"Paper-Like Canvas"**—a digital environment that mimics the clarity and tactile satisfaction of a physical habit journal. The brand personality bridges the gap between disciplined structure and friendly companionship. It uses **Modern Minimalism** with a focus on dimensional layering and high-contrast accents to evoke feelings of persistence, achievement, and clarity.

The emotional response is centered on the "Stamp" metaphor: a physical ink impression that signifies completion. By combining a clean, professional indigo foundation with a vibrant, energetic red accent, the UI motivates users to maintain their streaks while feeling supported by a sophisticated tool.

**Key Visual Principles:**
- **Paper Backdrop:** High-quality whitespace using a soft blue-grey canvas to reduce eye strain.
- **Dimensional Layering:** Pure white cards with hairline borders create depth without heavy shadows.
- **Tactile Rewards:** Rotated "ink stamps" and high-contrast progress indicators provide immediate visual satisfaction.
- **Friendly Professionalism:** Rounded corners (up to 20px) and bold, readable typography keep the interface approachable yet authoritative.

## Colors

The palette is strategically focused on three functional roles: Foundation, Action, and Achievement.

- **Primary (Brand Indigo - #4C6EF5):** Represents discipline and stability. Used for primary actions, navigation states, and focus indicators.
- **Secondary (Stamp Red - #E8503A):** Represents the "ink stamp." Used for completion highlights, progress meters, and critical call-to-actions.
- **Tertiary (Stamp Soft - #FDEEEB):** A peach-tinted red used for backgrounds of completed states, providing a warm, rewarding glow.
- **Neutral (Surface Canvas - #F6F7FC):** A paper-like grey-blue that serves as the root background.

**Semantic & Functional Colors:**
- **Surface Lowest (#FFFFFF):** Used for cards and containers to pop against the neutral canvas.
- **Outline Variant (#E7EAF3):** Used for hairline borders (1px) to define card boundaries.
- **Warning (#FFDAD6):** Reserved for overdue habits or urgent missed windows.
- **Morning Accent (#FFF3E6):** Paired with dark bronze text (#B05E00) for time-of-day metadata.

## Typography

The typography system exclusively uses **Nanum Gothic**, creating a clean, friendly, and structured aesthetic. The hierarchy is weight-driven, utilizing ExtraBold (800) for major headers to create a "printed" look against the digital canvas.

- **Headlines & Titles:** Use ExtraBold weights to command attention and anchor the page.
- **Labels:** Small labels (badges and metadata) use Bold (700) weights to ensure legibility despite their size.
- **Body:** Regular weights are used for descriptions and secondary text to ensure a comfortable reading experience.
- **Rhythm:** All typography follows a 4px vertical baseline. Space between headings and body text should ideally be 4px or 8px to maintain a tight, editorial feel.

## Layout & Spacing

This design system employs a **Fluid Grid** model with a strict adherence to a 4px spacing unit. The layout is optimized for handheld "thumb-zone" interactions.

- **Safe Areas:** A standard 16px root margin is applied to all screens to ensure content doesn't bleed into device edges.
- **Card Padding:** Routine cards and containers use 16px internal padding.
- **Sectioning:** Major vertical breaks between content blocks (e.g., "Daily Progress" vs "Upcoming Habits") use a 24px gap.
- **Grids:** The Certification Gallery uses a 2-column grid with 12px gutters. Items should maintain a 4:3 or 0.78 aspect ratio to ensure consistent visual rhythm.
- **Mobile-First Reflow:** On smaller screens, side-by-side elements (like metadata chips) should wrap to maintain a minimum touch target width.

## Elevation & Depth

Depth in this system is achieved through **Tonal Layers and Low-Contrast Outlines** rather than traditional drop shadows.

- **Level 0 (Neutral Canvas):** The `#F6F7FC` background serves as the base layer.
- **Level 1 (Card Layer):** Pure white (`#FFFFFF`) containers sit directly on the canvas. Instead of shadows, they use a 1px hairline border (`#E7EAF3`) to create a crisp, modern physical presence.
- **Level 2 (Interactive/Floating):** Primary Floating Action Buttons (FABs) may use a very subtle, diffused ambient shadow (10% opacity) to signify they are the top-most interaction layer.
- **Focus States:** Active inputs or selected cards use a 1.6px border in Brand Indigo (`#4C6EF5`) to draw the eye without changing the layout height.

## Shapes

The shape language is "Soft-Modern," using generous radii to balance the bold, high-contrast colors.

- **Standard Elements:** Input fields, list items, and smaller containers use a `14px` radius.
- **Primary Containers:** Large Routine Cards use a `20px` radius to feel like distinct, approachable objects.
- **Badges/Chips:** Use `full` (pill-shaped) or `10px` rounding depending on the density of the information.
- **The Stamp:** Circular elements (buttons and status indicators) must maintain a perfect 1:1 aspect ratio.

## Components

### Buttons
- **Primary (Stamp) Button:** 52px height, 14px radius, Bold typography. Uses Brand Indigo for standard actions and Stamp Red for the final "Complete" trigger.
- **Floating Action Button:** 18px radius, Brand Indigo background with white icons.

### The Signature Stamp (도장)
- **Design:** A circular mark with a thick `#E8503A` border.
- **State:** When completed, the interior is filled with `#FDEEEB` and tilted exactly **-8 degrees** counter-clockwise to mimic a hand-pressed ink stamp.
- **Iconography:** Use a heavy-weight checkmark or the text "UP!" inside the stamp.

### Cards & Inputs
- **Routine Cards:** White background, 20px radius, 1px `#E7EAF3` border. Contents should be left-aligned for readability, with progress bars hugging the bottom or right side.
- **Input Fields:** Filled style (no border), 14px radius, using a soft tint of the neutral color. Labels sit above the field in Label-Large typography.

### Progress & Feed
- **Progress Bars:** 5px thickness, using Stamp Red for the "filled" portion and a 12% opacity of the same color for the track.
- **Certification Gallery:** Images must have a 16px radius and include a bottom-left timestamp watermark (white text with a 55% black semi-transparent backing box).