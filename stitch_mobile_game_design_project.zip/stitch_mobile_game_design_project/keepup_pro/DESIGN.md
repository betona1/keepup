---
name: KeepUp Pro
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  stat-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  body-base:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 21px
    letterSpacing: '0'
  body-bold:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 21px
    letterSpacing: '0'
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 24px
  margin-mobile: 16px
  gutter: 12px
---

## Brand & Style
The design system for this habit tracker is built on the philosophy of **"The Digital Ledger"**—a professional, high-performance environment that treats habit formation with the gravity of a contract. The style is a sophisticated blend of **Modern Minimalism** and **Tactile Precision**, designed to evoke a sense of clarity, discipline, and high-reward accomplishment.

The interface mimics a premium physical planner, using a "paper-and-slate" aesthetic. It replaces heavy shadows with crisp, hair-line borders to create a structured, flat-depth workspace. The emotional core of the system is the **Official Red Stamp (인주 도장)** metaphor: completing a habit isn't just a click, it's a ritualistic verification. Every successful action is marked by a vermilion stamp, tilted at a humanistic -8 degrees to simulate the physical gesture of stamping paper.

This design system is intended to feel logical and authoritative, moving away from "playful" gamification toward "professional" growth. It utilizes high-contrast typography and a rigid 4px rhythmic grid to provide the user with a feeling of total control and momentum.

## Colors
The palette is rooted in productivity and logical focus.
- **Primary (Focus Blue):** Used for interactive elements, active states, and focus-driven navigation. It represents the intellectual commitment to a routine.
- **Secondary (Dark Slate):** The bedrock of the system. Used for high-contrast typography and structural reliability.
- **Tertiary (Success Green):** Reserved for positive momentum, completion percentages, and high-frequency streaks.
- **Accent (Stamp Vermilion):** A high-energy, traditional red used exclusively for the "Stamp" ritual and urgent call-to-actions.
- **Neutral (Paper Slate):** A cool, slate-tinted white (#F8FAFC) that serves as the canvas, providing a crisp alternative to pure white for reduced eye strain during long-term use.

Surface containers are always pure white (#FFFFFF) to pop against the neutral background, while borders use a muted hairline slate (#E2E8F0) for surgical definition.

## Typography
The system uses a dual-font strategy. **Inter** handles all numeric data, headers, and UI labels to provide a systematic, technical feel. **Noto Sans** (or NanumGothic for specialized locales) is used for body copy and reflective logs to ensure maximum readability and a slightly more approachable tone for long-form text.

- **Headlines:** Use tight letter spacing (-0.02em) and heavy weights (700-800) to create strong visual anchors.
- **Stats:** The `stat-lg` style is the hero of the dashboard, making achievement numbers unmissable.
- **Labels:** Use `label-caps` with increased tracking (0.05em) for high legibility at small scales, ideal for status badges and metadata.

## Layout & Spacing
This system follows a strict **4px baseline rhythm**. All margins, paddings, and gaps must be multiples of 4.

- **Grid Model:** A mobile-first, single-column fluid layout for habit feeds. 
- **Safe Margins:** A standard 16px side margin is enforced across all screens.
- **Card Spacing:** Use 12px gaps (`md`) between items in a list, and 16px (`lg`) internal padding within cards.
- **Visual Breathing Room:** A 96px bottom buffer is required on all scrollable feeds to ensure content is never obscured by the Floating Action Button or bottom navigation.
- **History/Gallery:** Uses a fixed 2-column grid with a 12px gutter and a locked 0.78 aspect ratio for habit photo evidence.

## Elevation & Depth
Depth is communicated through **Tonal Layering and Hairline Outlines** rather than traditional shadows. This maintains the "clean ledger" aesthetic.

- **Level 0 (Canvas):** The Paper Slate background (#F8FAFC).
- **Level 1 (Cards):** Pure White (#FFFFFF) surfaces. Instead of a shadow, these cards use a 1px solid border of `#E2E8F0` (Hairline Outline).
- **Interactive Focus:** When an element is active or selected, the border thickness may increase to 1.5px and change to the Primary Focus Blue, or the background may shift to a 10% opacity blue tint.
- **The Stamp:** The completed state "stamps" over the Level 1 surface, appearing to exist on a layer slightly above the card, indicated by its rotation and vibrant color contrast.

## Shapes
The shape language is professional and balanced.
- **Cards & Primary Containers:** Use a `14px` (`DEFAULT`) to `20px` (`rounded-lg`) radius to soften the high-contrast professional look.
- **Action Buttons:** Standardized at `14px` to match card containers.
- **Pills & Chips:** Use `rounded-full` (9999px) for category tags and status indicators to differentiate them from functional card blocks.
- **The Stamp:** A perfect circle, reinforcing the "seal of approval" metaphor.

## Components
- **Habit Cards:** Flat white containers with 1px hairline borders. Must feature a left-aligned "Stamp Zone" (a 50px circle). If incomplete, it's a subtle blue tint with a camera icon; if complete, it's the Vermilion Stamp tilted at -8°.
- **Buttons:** Large touch targets (min 52px height). Primary buttons are solid Focus Blue with white bold text. Secondary buttons use a slate-gray fill (#F1F5F9) with no border.
- **Verification Gauges:** Circular progress tracks (10px thickness). Inactive tracks are light slate; active progress is Blue; completed state triggers a transition to Stamp Vermilion for the entire track and border.
- **Stamp Calendar:** A grid of 7 columns. Today is marked by a Blue border. Completed days display a mini angled red stamp (26px). Missed days use a soft red wash (#FEE2E2).
- **Input Fields:** Background-filled (#F1F5F9) with no borders and 14px rounded corners. Placeholder text remains static above the field for persistent context.
- **Ticker Marquee:** A thin horizontal banner at the top of the app bar scrolling user commitments in Primary Blue bold text.