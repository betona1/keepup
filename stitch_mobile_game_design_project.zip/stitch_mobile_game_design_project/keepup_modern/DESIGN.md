---
name: KeepUp Modern
colors:
  surface: '#f8f9fd'
  surface-dim: '#d8dade'
  surface-bright: '#f8f9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3f8'
  surface-container: '#eceef2'
  surface-container-high: '#e7e8ec'
  surface-container-highest: '#e1e2e6'
  on-surface: '#191c1f'
  on-surface-variant: '#444654'
  inverse-surface: '#2e3134'
  inverse-on-surface: '#eff1f5'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2a50d8'
  primary: '#274ed5'
  on-primary: '#ffffff'
  primary-container: '#4669f0'
  on-primary-container: '#fffbff'
  inverse-primary: '#b8c4ff'
  secondary: '#b32a19'
  on-secondary: '#ffffff'
  secondary-container: '#fc5e47'
  on-secondary-container: '#5f0400'
  tertiary: '#006947'
  on-tertiary: '#ffffff'
  tertiary-container: '#00855b'
  on-tertiary-container: '#f5fff6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001355'
  on-primary-fixed-variant: '#0036bc'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a7'
  on-secondary-fixed: '#400200'
  on-secondary-fixed-variant: '#900e02'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9fd'
  on-background: '#191c1f'
  surface-variant: '#e1e2e6'
typography:
  headline-lg:
    fontFamily: Nanum Gothic
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Nanum Gothic
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 26px
    letterSpacing: '0'
  title-md:
    fontFamily: Nanum Gothic
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: '0'
  body-base:
    fontFamily: Nanum Gothic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  label-bold:
    fontFamily: Nanum Gothic
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  xxl: 32px
  margin-mobile: 16px
  margin-desktop: 32px
  max-width-mobile: 640px
  max-width-desktop: 1200px
---

## Brand & Style

The design system for this habit-tracking product is built on the **Stamp Metaphor**—a fusion of modern productivity and the tactile, organic satisfaction of physical certification. The brand personality is professional, structured, and motivating, aiming to evoke a sense of dependability and accomplishment.

The design style is **Corporate / Modern with Tactile Accents**. It utilizes a clean, systematic layout typical of high-end SaaS products but breaks the rigidity with "squishy" physical metaphors, specifically the tilted "Seal Red" stamp used for success states. This approach balances the efficiency of a digital tool with the emotional reward of an analog journal. 

**Key Visual Principles:**
- **The Paper Scaffold:** Using a very light, cool-tinted background to mimic premium paper, reducing eye strain and providing a professional canvas.
- **Organic Certification:** Completed states are never just "checked"; they are "stamped." This is visualized through tilted, double-ringed circular icons that break the grid slightly to feel human and physical.
- **Structured Energy:** High-contrast indigo is used for structural focus, while vibrant gradients and coral accents provide the energetic "push" needed for habit formation.

## Colors

The color palette is highly functional, mapping specific emotional states to color roles:

- **Primary (Brand Indigo):** Represents focus, reliability, and structural order. Used for primary actions and active states.
- **Secondary (Seal Red):** The "Authentication" color. Used for the signature stamp, urgent highlights, and final accomplishments.
- **Tertiary (Success Green):** Used exclusively for streaks, positive compliance, and successful data synchronization.
- **Neutral (Ink Charcoal):** A soft black used for primary typography to maintain high legibility without the harshness of pure black.
- **Functional Accents:** 
    - **Focus Amber (#B05E00):** Used for time-windows and result-based metrics.
    - **Coral (#FF8A75):** A warm beacon used for decorative elements like quotation bullets.
- **Surface & Background:** The background uses a "Paper Blue-Gray" (#F6F7FC) to provide a soft contrast against "Clean Card Surfaces" (#FFFFFF).

## Typography

This design system uses **Nanum Gothic** across all levels. This choice is driven by its optimized performance at small sizes and its clean, geometric clarity which handles both Latin and Korean characters with professional ease.

- **Scale & Weight:** Headings use heavy weights (800) to create a clear visual hierarchy against the light-weight cards.
- **Spacing:** Titles feature a slightly tightened letter-spacing (-0.01em) to feel more impactful and modern. Body copy maintains a generous 1.5 line-height to ensure comfortable reading of habit descriptions and metadata.
- **Mobile Considerations:** The typography scale is intentionally compact (max 24px) to ensure titles do not wrap awkwardly on mobile device screens, maintaining a single-column rhythm.

## Layout & Spacing

The layout philosophy follows a **Fluid Grid** model for mobile and a **Fixed Grid** model for desktop.

- **Base Unit:** A strict 4px grid governs all spacing, ensuring vertical rhythm.
- **Mobile Layout:** A single-column fluid stack with 16px side margins. The content width is capped at 640px to prevent list items from becoming too wide and losing scannability.
- **Desktop Layout:** A 12-column grid within a 1200px container. On web, the UI often presents a "phone simulation" or centered card stack to maintain the intimacy of the mobile experience.
- **Spacing Logic:** Use `lg` (16px) for internal card padding and `xxl` (32px) for major section breaks or between the Hero area and the content list.

## Elevation & Depth

Hierarchy is conveyed through **Low-contrast outlines** and **Ambient shadows**. 

- **The Primary Layer:** Cards and containers do not use heavy shadows. Instead, they use a 1px solid border in "Lavender-Gray" (#E7EAF3). This keeps the interface feeling crisp and "printed."
- **Subtle Depth:** For high-priority elements like active habit cards or primary buttons, a very soft, indigo-tinted shadow is used. 
- **Shadow Character:** Shadows should be highly diffused with a 4px to 12px blur radius and very low opacity (2-4%), tinted with the primary Indigo color (#4C6EF5) rather than pure black to maintain the "Paper" aesthetic.
- **Tonal Stacking:** The background is #F6F7FC, and the interactive cards are #FFFFFF. This 1-tier elevation difference is the primary way of separating content from the scaffold.

## Shapes

The shape language is **Rounded** and friendly, leaning towards a "Soft-SaaS" aesthetic.

- **Cards & Banners:** Use a generous `rounded-xl` (1.5rem / 24px) to emphasize the soft, welcoming nature of the journal.
- **Buttons & Inputs:** Use a standard `rounded-lg` (1rem / 16px) to maintain a professional, clickable appearance.
- **Pills & Tags:** Status indicators and badges always use the `full` (pill-shaped) radius to differentiate them from functional containers.
- **The Stamp:** A perfect circle, but always rendered with a slight (-8 degree) rotation to break the geometric perfection of the rest of the UI.

## Components

### Buttons
- **Primary:** Filled Indigo (#4C6EF5) with white text. 48px-52px height for mobile touch targets.
- **Outline:** 1px Lavender-Gray border with Indigo text.
- **Floating Action:** Large circular buttons in Indigo, used for the main "Add Habit" or "Sync" actions.

### Cards (The Core Unit)
- **Standard Card:** White surface, 1px #E7EAF3 border, 20px-24px corner radius.
- **Interactive State:** Contains a 50px circular trigger on the left (10% Indigo tint) for photo-proof actions.
- **Completed State:** The trigger morphs into the "Seal Red" StampMark.

### Input Fields
- Filled style using #F1F3F9 background and 14px-16px corner radius.
- **Focus State:** Transitions to a 1.5px solid Brand Indigo border.

### Chips & Badges
- **Pill-shaped capsules.**
- **Urgent:** Red tint (#FFDAD6) with dark red text and alarm emoji.
- **Success:** Green tint (#D1FAE5) with deep green text.

### Domain Specific: The StampMark
- A double-circle ring icon.
- Tilted exactly -8 degrees to the left.
- Used to "strike through" or overlay completed habit cards, providing the primary visual reward of the system.

### QuoteCard
- Linear gradient background from #5C7CFA to #3B5BDB.
- Features a Coral (#FF8A75) accent dot for the author attribution.
- Bold white typography for high-contrast impact.